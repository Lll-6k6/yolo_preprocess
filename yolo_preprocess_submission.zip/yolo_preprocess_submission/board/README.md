# 上板测试说明

## 硬件连接

1. 开发板: MicroPhase Z7-Lite (Zynq-7020)
2. 显示: HDMI 显示器 (1024x600)
3. 电源: Type-C 供电
4. 按键: KEY1 用于手动切换模式

## 测试步骤

1. 打开 Vivado Hardware Manager
2. 连接开发板 JTAG
3. 下载 bitstream
4. 观察 HDMI 输出

## 预期结果

- 启动后自动进入模式 0 (彩色原图)
- 每 120 帧 (约 2 秒) 自动切换到下一个模式
- 按 KEY1 可手动切换模式
- 屏幕上有一个移动方块，在模式切换时保持连续运动

## 七种模式预期显示

| 模式 | 显示内容 |
|------|----------|
| 0 | 彩色测试图案 (RGB 条纹) |
| 1 | 灰度测试图案 |
| 2 | 模糊效果 (3x3 均值滤波) |
| 3 | Sobel 边缘检测结果 |
| 4 | 四宫格分屏显示四种模式 |
| 5 | 伽马校正效果 |
| 6 | Letterbox 缩放模式 |

## 实测输出

实测截图见 `data/` 目录:
- `system_architecture_zh.png` - 系统架构图
- `hierarchy.png` - Vivado 工程层级
- `utilization.png` - 资源占用报告
