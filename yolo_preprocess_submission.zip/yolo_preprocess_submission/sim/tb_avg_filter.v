// tb_avg_filter.v -- testbench for 3x3 average filter
`timescale 1ns / 1ps

module tb_avg_filter;

    reg clk = 0;
    reg rst_n = 0;
    reg [7:0] din = 0;
    reg       valid = 0;
    wire [7:0] dout;
    wire       valid_out;

    avg_filter_3x3 #(.IMG_W(8)) uut (
        .clk(clk), .rst_n(rst_n),
        .pixel_in(din), .valid_in(valid),
        .pixel_out(dout), .valid_out(valid_out)
    );

    always #5 clk = ~clk;

    integer i;
    reg [7:0] test_img [0:63]; // 8x8 image

    initial begin
        // simple test image: left half = 0, right half = 255
        for (i = 0; i < 64; i = i + 1)
            test_img[i] = (i % 8 < 4) ? 8'd0 : 8'd255;

        rst_n = 0;
        #20;
        rst_n = 1;
        #10;

        // feed 8x8 = 64 pixels
        for (i = 0; i < 64; i = i + 1) begin
            @(posedge clk);
            din = test_img[i];
            valid = 1;
        end
        @(posedge clk);
        valid = 0;

        #200;
        $display("[TB] avg filter test done");
        $finish;
    end

    always @(posedge clk) begin
        if (valid_out)
            $display("[%0t] filtered = %0d", $time, dout);
    end

endmodule
