// tb_image_source.v -- testbench for image_source
// Verifies: produces exactly IMG_W*IMG_H pixels, correct SOF/EOR
`timescale 1ns / 1ps

module tb_image_source;

    reg clk = 0;
    reg rst_n = 0;
    wire        tvalid;
    reg         tready = 1;
    wire [23:0] tdata;
    wire        tlast;
    wire        tuser;

    image_source #(.IMG_W(8), .IMG_H(4)) uut (
        .clk(clk), .rst_n(rst_n),
        .m_axis_tvalid(tvalid), .m_axis_tready(tready),
        .m_axis_tdata(tdata), .m_axis_tlast(tlast), .m_axis_tuser(tuser)
    );

    always #5 clk = ~clk;   // 100MHz sim clock

    integer pix_count = 0;
    integer row_count = 0;

    always @(posedge clk) begin
        if (tvalid && tready) begin
            pix_count <= pix_count + 1;
            if (tlast) row_count <= row_count + 1;
            if (tuser) $display("[%0t] SOF detected", $time);
            $display("[%0t] pix=%0d row_end=%b RGB=%h", $time, pix_count, tlast, tdata);
        end
    end

    initial begin
        rst_n = 0;
        #20;
        rst_n = 1;
        // 8*4 = 32 pixels should be emitted
        #1000;
        $display("[TB] total pixels = %0d (expect 32), rows = %0d (expect 4)", pix_count, row_count);
        if (pix_count == 32 && row_count == 4)
            $display("[TB] PASS");
        else
            $display("[TB] FAIL");
        $finish;
    end

endmodule
