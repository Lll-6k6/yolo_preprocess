// tb_normalizer.v -- testbench for normalizer
// out = (pixel - 128) >> 1
// Expected:
//   0   -> (-128)>>1 = -64
//   128 -> 0
//   255 -> (127)>>1 = 63
//   64  -> (-64)>>1 = -32
//   192 -> (64)>>1  = 32
`timescale 1ns / 1ps

module tb_normalizer;

    reg  [7:0] pin = 0;
    wire [7:0] pout;

    normalizer uut (.pixel_in(pin), .pixel_out(pout));

    // print signed value
    wire signed [7:0] pout_s = pout;

    initial begin
        $display(" pin | pout_s | expect");
        pin = 8'd0;    #1; $display("%3d | %4d   | expect -64", pin, pout_s);
        pin = 8'd64;   #1; $display("%3d | %4d   | expect -32", pin, pout_s);
        pin = 8'd128;   #1; $display("%3d | %4d   | expect 0",   pin, pout_s);
        pin = 8'd192;   #1; $display("%3d | %4d   | expect 32",  pin, pout_s);
        pin = 8'd255;   #1; $display("%3d | %4d   | expect 63",  pin, pout_s);
        $display("[TB] All cases done.");
        $finish;
    end

endmodule
