// tb_rgb_to_gray.v -- testbench for rgb_to_gray
// Expected values (Y = (77R + 150G + 29B) >> 8):
//   black (0,0,0)       -> 0
//   white (255,255,255) -> 255
//   red   (255,0,0)     -> (77*255)>>8 = 76
//   green (0,255,0)    -> (150*255)>>8 = 149
//   blue  (0,0,255)     -> (29*255)>>8 = 28
`timescale 1ns / 1ps

module tb_rgb_to_gray;

    reg  [7:0] r = 0, g = 0, b = 0;
    wire [7:0] gray;

    rgb_to_gray uut (
        .r(r), .g(g), .b(b), .gray(gray)
    );

    initial begin
        $display(" R   G   B  | gray | expect");
        {r,g,b} = {8'd0,   8'd0,   8'd0};   #10;
        $display("%3d %3d %3d | %4d | expect 0",   r, g, b, gray);
        {r,g,b} = {8'd255, 8'd255, 8'd255}; #10;
        $display("%3d %3d %3d | %4d | expect 255", r, g, b, gray);
        {r,g,b} = {8'd255, 8'd0,   8'd0};   #10;
        $display("%3d %3d %3d | %4d | expect 76",  r, g, b, gray);
        {r,g,b} = {8'd0,   8'd255, 8'd0};   #10;
        $display("%3d %3d %3d | %4d | expect 149", r, g, b, gray);
        {r,g,b} = {8'd0,   8'd0,   8'd255}; #10;
        $display("%3d %3d %3d | %4d | expect 28",  r, g, b, gray);
        $display("[TB] All cases done.");
        $finish;
    end

endmodule
