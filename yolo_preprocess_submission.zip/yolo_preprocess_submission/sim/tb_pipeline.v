// tb_pipeline.v -- system-level testbench for pipeline_top
// Drives reset, starts one frame, logs every output pixel
`timescale 1ns / 1ps

module tb_pipeline;

    reg clk = 0;
    reg rst_n = 0;
    wire        tvalid;
    reg         tready = 1;
    wire [7:0]  tdata;
    wire        tlast;
    wire        tuser;

    pipeline_top #(.IMG_W(8), .IMG_H(4)) uut (
        .clk(clk), .rst_n(rst_n),
        .m_axis_tvalid(tvalid), .m_axis_tready(tready),
        .m_axis_tdata(tdata), .m_axis_tlast(tlast), .m_axis_tuser(tuser)
    );

    always #5 clk = ~clk;

    integer pix = 0;
    integer sof_count = 0;

    always @(posedge clk) begin
        if (tvalid && tready) begin
            pix <= pix + 1;
            if (tuser) sof_count <= sof_count + 1;
            $display("[%0t] pix=%0d norm=%0d row_end=%b SOF=%b", $time, pix, $signed(tdata), tlast, tuser);
        end
    end

    initial begin
        rst_n = 0;
        #20;
        rst_n = 1;
        #1000;
        $display("[TB] total pixels = %0d, SOF count = %0d", pix, sof_count);
        if (sof_count >= 2 && pix >= 32) $display("[TB] PIPELINE PASS");
        else                            $display("[TB] PIPELINE FAIL");
        $finish;
    end

endmodule
