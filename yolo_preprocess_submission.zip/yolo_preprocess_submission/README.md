# FPGA-Based YOLO Image Preprocessing Pipeline

## 项目简介

本项目在 AMD Xilinx Zynq-7020 (XC7Z020CLG400-1) 上实现了一套纯 RTL 的 YOLO 图像预处理流水线，通过 HDMI 实时输出，支持七种图像处理模式。

- **硬件平台**: MicroPhase Z7-Lite 开发板 (Zynq-7020)
- **像素时钟**: 50 MHz
- **输出分辨率**: 1024x600 @ 60Hz
- **吞吐率**: 50 MP/s
- **一帧延迟**: 12.3 ms
- **模块流水线延迟**: 3 拍 (60 ns)

## 七种处理模式

| 模式 | 说明 |
|------|------|
| 0 | 彩色原图 |
| 1 | 灰度 (Y = 0.299R + 0.587G + 0.114B) |
| 2 | 3x3 均值滤波 |
| 3 | Sobel 边缘检测 (Gx, Gy) |
| 4 | 四宫格分屏 |
| 5 | 伽马校正 (gamma=2.2) |
| 6 | Letterbox 缩放 |

## 资源占用

| 资源 | 使用 | 总量 | 百分比 |
|------|------|------|--------|
| LUT | 12097 | 53200 | 22.74% |
| FF | 33428 | 106400 | 31.42% |
| IO | 12 | 125 | 9.60% |
| MMCM | 1 | 4 | 25.00% |
| BRAM | 0 | 140 | 0% |
| DSP | 0 | 220 | 0% |

## 目录结构

```
├── README.md           # 本文件
├── src/                # RTL 源码
├── sim/                # 仿真 Testbench
├── build/              # 构建脚本与综合报告
├── board/              # 上板工程与实测说明
├── data/               # 测试数据与截图
├── skill/              # 技能包
│   └── README.md
└── report/             # 设计报告与大模型协作记录
```

## 复现步骤

### 1. 环境准备

- Vivado 2025.2
- 目标器件: xc7z020clg400-1

### 2. 创建 Vivado 工程

1. 新建工程，选择器件 xc7z020clg400-1
2. 添加 `src/` 目录下所有 `.v` 文件为 Design Sources
3. 添加 `sim/` 目录下 `.v` 文件为 Simulation Sources
4. 添加 Clocking Wizard IP (clk_wiz_0): 输入 50MHz, 输出 50MHz 和 250MHz
5. 顶层模块选择 `top_hdmi_demo`

### 3. 仿真验证

在 Vivado 中运行各 Testbench：
- `tb_rgb_to_gray` - 验证灰度转换
- `tb_avg_filter` - 验证 3x3 均值滤波
- `tb_sobel_edge` - 验证边缘检测
- `tb_pipeline` - 验证整体流水线

### 4. 综合实现

1. Run Synthesis
2. Run Implementation
3. Generate Bitstream

### 5. 上板测试

1. 将 bitstream 下载到 Z7-Lite 开发板
2. 连接 HDMI 显示器 (1024x600)
3. 按 KEY1 按键切换模式，或等待自动轮换 (每 120 帧切换一次)

## 大模型协作

本项目使用了大模型辅助完成：
- RTL 代码生成与调试
- 仿真 Testbench 编写
- 资源分析与优化建议
- 技术报告与海报撰写

详见 `report/collaboration_log.md`
