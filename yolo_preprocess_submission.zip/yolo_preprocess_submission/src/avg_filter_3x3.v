// avg_filter_3x3.v -- 3x3 average filter for grayscale pixel stream
// Pipelined 3 stages: read linebuf -> shift columns -> sum
`timescale 1ns / 1ps

module avg_filter_3x3 #(
    parameter IMG_W = 64
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire [7:0]  pixel_in,
    input  wire        valid_in,
    output reg  [7:0]  pixel_out,
    output reg         valid_out
);

    reg [7:0] line_above [0:IMG_W-1];  // row above current
    reg [7:0] line_two   [0:IMG_W-1];  // two rows above
    reg [10:0] x = 0;
    integer k;

    // force clear line buffers at simulation start
    initial begin
        for (k = 0; k < IMG_W; k = k + 1) begin
            line_above[k] = 8'd0;
            line_two[k]   = 8'd0;
        end
    end

    // ---- stage 1: read line buffers, write current row ----
    reg [7:0] s1_curr, s1_above, s1_two;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            s1_curr <= 0; s1_above <= 0; s1_two <= 0;
            x <= 0;
            for (k = 0; k < IMG_W; k = k + 1) begin
                line_above[k] <= 0;
                line_two[k]   <= 0;
            end
        end else if (valid_in) begin
            s1_curr  <= pixel_in;
            s1_above <= line_above[x];
            s1_two   <= line_two[x];
            line_above[x] <= pixel_in;
            line_two[x]   <= line_above[x];
            x <= (x == IMG_W-1) ? 0 : x + 1;
        end
    end

    // ---- stage 2: 3-pixel column delay chain ----
    reg [7:0] s2_curr0, s2_curr1, s2_curr2;
    reg [7:0] s2_above0, s2_above1, s2_above2;
    reg [7:0] s2_two0, s2_two1, s2_two2;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            {s2_curr0,s2_curr1,s2_curr2} <= 0;
            {s2_above0,s2_above1,s2_above2} <= 0;
            {s2_two0,s2_two1,s2_two2} <= 0;
        end else if (valid_in) begin
            s2_curr0  <= s1_curr;  s2_curr1  <= s2_curr0;  s2_curr2  <= s2_curr1;
            s2_above0 <= s1_above; s2_above1 <= s2_above0; s2_above2 <= s2_above1;
            s2_two0   <= s1_two;   s2_two1   <= s2_two0;   s2_two2   <= s2_two1;
        end
    end

    // ---- stage 3: sum 9 pixels, >>3 (approx /9) ----
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pixel_out <= 0;
            valid_out <= 0;
        end else begin
            pixel_out <= (s2_curr0  + s2_curr1  + s2_curr2 +
                          s2_above0 + s2_above1 + s2_above2 +
                          s2_two0   + s2_two1   + s2_two2) >> 3;
            valid_out <= valid_in;
        end
    end

endmodule
