// serializer.v -- 10-bit TMDS serial output using OSERDESE2 master+slave
`timescale 1ns / 1ps

module serializer (
    input  wire       pixel_clk,
    input  wire       serial_clk,
    input  wire       rst_n,
    input  wire [9:0] data_in,
    output wire       ser_out
);

    wire [1:0] cascade;

    OSERDESE2 #(
        .DATA_RATE_OQ("DDR"),
        .DATA_RATE_TQ("SDR"),
        .DATA_WIDTH(10),
        .SERDES_MODE("MASTER"),
        .TBYTE_CTL("FALSE"),
        .TBYTE_SRC("FALSE"),
        .TRISTATE_WIDTH(1)
    ) u_master (
        .D1(data_in[0]), .D2(data_in[1]),
        .D3(data_in[2]), .D4(data_in[3]),
        .D5(data_in[4]), .D6(data_in[5]),
        .D7(data_in[6]), .D8(data_in[7]),
        .T1(1'b0), .T2(1'b0), .T3(1'b0), .T4(1'b0),
        .OCE(1'b1), .CLK(serial_clk), .CLKDIV(pixel_clk),
        .OQ(ser_out), .OFB(), .TFB(), .TQ(),
        .SHIFTOUT1(), .SHIFTOUT2(),
        .SHIFTIN1(cascade[0]), .SHIFTIN2(cascade[1]),
        .TBYTEIN(1'b0), .TBYTEOUT(),
        .TCE(1'b0),
        .RST(~rst_n)
    );

    OSERDESE2 #(
        .DATA_RATE_OQ("DDR"),
        .DATA_RATE_TQ("SDR"),
        .DATA_WIDTH(10),
        .SERDES_MODE("SLAVE"),
        .TBYTE_CTL("FALSE"),
        .TBYTE_SRC("FALSE"),
        .TRISTATE_WIDTH(1)
    ) u_slave (
        .D1(1'b0), .D2(1'b0),
        .D3(data_in[8]), .D4(data_in[9]),
        .D5(1'b0), .D6(1'b0),
        .D7(1'b0), .D8(1'b0),
        .T1(1'b0), .T2(1'b0), .T3(1'b0), .T4(1'b0),
        .OCE(1'b1), .CLK(serial_clk), .CLKDIV(pixel_clk),
        .OQ(), .OFB(), .TFB(), .TQ(),
        .SHIFTOUT1(cascade[0]), .SHIFTOUT2(cascade[1]),
        .SHIFTIN1(), .SHIFTIN2(),
        .TBYTEIN(1'b0), .TBYTEOUT(),
        .TCE(1'b0),
        .RST(~rst_n)
    );

endmodule
