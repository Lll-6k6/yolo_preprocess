// video_timing.v -- 1024x600@60Hz video timing generator
`timescale 1ns / 1ps

module video_timing (
    input  wire       pixel_clk,
    input  wire       rst_n,
    output wire [10:0] hcnt,
    output wire [10:0] vcnt,
    output wire       hs,
    output wire       vs,
    output wire       de,
    output wire       active
);

    localparam H_ACTIVE = 1024;
    localparam H_FP     = 160;
    localparam H_SYNC   = 20;
    localparam H_BP     = 140;
    localparam H_TOTAL  = 1344;

    localparam V_ACTIVE = 600;
    localparam V_FP     = 12;
    localparam V_SYNC   = 3;
    localparam V_BP     = 23;
    localparam V_TOTAL  = 638;

    reg [10:0] hcnt_r, vcnt_r;
    reg        hs_r, vs_r;

    always @(posedge pixel_clk or negedge rst_n) begin
        if (!rst_n) begin
            hcnt_r <= 0; vcnt_r <= 0;
            hs_r <= 0; vs_r <= 0;
        end else begin
            if (hcnt_r == H_TOTAL-1) hcnt_r <= 0;
            else                     hcnt_r <= hcnt_r + 1;

            if (hcnt_r == H_TOTAL-1) begin
                if (vcnt_r == V_TOTAL-1) vcnt_r <= 0;
                else                     vcnt_r <= vcnt_r + 1;
            end

            hs_r <= (hcnt_r >= H_ACTIVE + H_FP) && (hcnt_r < H_ACTIVE + H_FP + H_SYNC);
            vs_r <= (vcnt_r >= V_ACTIVE + V_FP) && (vcnt_r < V_ACTIVE + V_FP + V_SYNC);
        end
    end

    assign hcnt   = hcnt_r;
    assign vcnt   = vcnt_r;
    assign hs     = hs_r;
    assign vs     = vs_r;
    assign active = (hcnt_r < H_ACTIVE) && (vcnt_r < V_ACTIVE);
    assign de     = active;

endmodule
