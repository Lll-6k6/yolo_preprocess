// uart_tx.v -- simple UART transmitter, 115200 baud, 8N1
// Clock: 50MHz. Baud divider = 50e6 / 115200 = 434
`timescale 1ns / 1ps

module uart_tx #(
    parameter CLK_HZ = 50000000,
    parameter BAUD   = 9600
)(
    input  wire       clk,
    input  wire       rst_n,
    input  wire [7:0] tx_data,
    input  wire       tx_valid,
    output reg        tx_ready,
    output reg        tx_pin
);

    localparam DIV = CLK_HZ / BAUD;

    reg [15:0] baud_cnt = 0;
    reg [3:0]  bit_cnt  = 0;
    reg [7:0]  data_buf = 0;
    reg        busy     = 0;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            baud_cnt <= 0; bit_cnt <= 0;
            data_buf <= 0; busy <= 0; tx_pin <= 1; tx_ready <= 1;
        end else if (!busy && tx_valid && tx_ready) begin
            tx_ready <= 0;
            busy     <= 1;
            data_buf <= tx_data;
            baud_cnt <= 0;
            bit_cnt  <= 0;
            tx_pin   <= 0;       // start bit
        end else if (busy) begin
            if (baud_cnt == DIV-1) begin
                baud_cnt <= 0;
                case (bit_cnt)
                    0: tx_pin <= data_buf[0];
                    1: tx_pin <= data_buf[1];
                    2: tx_pin <= data_buf[2];
                    3: tx_pin <= data_buf[3];
                    4: tx_pin <= data_buf[4];
                    5: tx_pin <= data_buf[5];
                    6: tx_pin <= data_buf[6];
                    7: tx_pin <= data_buf[7];
                    8: tx_pin <= 1;
                    9: begin busy <= 0; tx_ready <= 1; end
                endcase
                bit_cnt <= bit_cnt + 1;
            end else begin
                baud_cnt <= baud_cnt + 1;
            end
        end
    end

endmodule
