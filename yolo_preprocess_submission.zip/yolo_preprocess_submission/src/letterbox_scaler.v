// letterbox_scaler.v -- simple 2:1 downscale + center black bars
// Input: 1024x600 pixel stream
// Output: 512x300 image centered in 1024x600 (black bars around)
`timescale 1ns / 1ps

module letterbox_scaler (
    input  wire       clk,
    input  wire       rst_n,
    input  wire [7:0] r_in, g_in, b_in,
    input  wire [10:0] hcnt, vcnt,
    input  wire       de,
    output reg  [7:0] r_out, g_out, b_out,
    output reg        de_out
);

    // target displayed image: 512x300 centered
    // x: 256..767 (center 512 wide)
    // y: 150..449 (center 300 tall)
    parameter X_OFF = 256;
    parameter Y_OFF = 150;

    // row buffer for vertical 2:1 downscale
    reg [7:0] row_buf_r [0:511];
    reg [7:0] row_buf_g [0:511];
    reg [7:0] row_buf_b [0:511];
    reg [10:0] x_wr;
    reg [10:0] y_in;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            r_out <= 0; g_out <= 0; b_out <= 0;
            de_out <= 0;
            x_wr <= 0;
            y_in <= 0;
        end else begin
            de_out <= de;

            // default: black
            r_out <= 8'd0;
            g_out <= 8'd0;
            b_out <= 8'd0;

            if (de) begin
                // write every other column (x%2==0) to row buffer
                if (hcnt[0] == 1'b0) begin
                    row_buf_r[hcnt[10:1]] <= r_in;
                    row_buf_g[hcnt[10:1]] <= g_in;
                    row_buf_b[hcnt[10:1]] <= b_in;
                end

                // determine if current output pixel is inside letterbox region
                // displayed x: hcnt - X_OFF, should be 0..511
                // displayed y: vcnt - Y_OFF, should be 0..299
                if (hcnt >= X_OFF && hcnt < X_OFF + 512 &&
                    vcnt >= Y_OFF && vcnt < Y_OFF + 300) begin
                    // read from row buffer
                    // input x = (hcnt - X_OFF) * 2, but we already wrote every other col
                    // so just index directly
                    r_out <= row_buf_r[hcnt[10:1] - X_OFF[10:1]];
                    g_out <= row_buf_g[hcnt[10:1] - X_OFF[10:1]];
                    b_out <= row_buf_b[hcnt[10:1] - X_OFF[10:1]];
                end
            end
        end
    end

endmodule
