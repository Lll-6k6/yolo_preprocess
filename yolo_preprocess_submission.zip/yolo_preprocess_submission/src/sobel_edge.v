// sobel_edge.v -- Sobel edge detection, 3-stage pipeline
// Stage1: read line buffers
// Stage2: column shift chain (3x3 window)
// Stage3: compute |Gx|+|Gy|
`timescale 1ns / 1ps

module sobel_edge #(
    parameter IMG_W = 1024
)(
    input  wire       clk,
    input  wire       rst_n,
    input  wire [7:0] pixel_in,
    input  wire       valid_in,
    output reg  [7:0] edge_out,
    output reg        valid_out
);

    reg [7:0] line1 [0:IMG_W-1];
    reg [7:0] line2 [0:IMG_W-1];
    reg [10:0] x;
    integer k;

    initial begin
        for (k = 0; k < IMG_W; k = k + 1) begin
            line1[k] = 8'd0;
            line2[k] = 8'd0;
        end
    end

    // Stage 1: read line buffers
    reg [7:0] s1_curr, s1_row1, s1_row2;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            s1_curr <= 0; s1_row1 <= 0; s1_row2 <= 0;
            x <= 0;
            for (k = 0; k < IMG_W; k = k + 1) begin
                line1[k] <= 0;
                line2[k] <= 0;
            end
        end else if (valid_in) begin
            s1_curr <= pixel_in;
            s1_row1 <= line1[x];
            s1_row2 <= line2[x];
            line1[x] <= pixel_in;
            line2[x] <= line1[x];
            x <= (x == IMG_W-1) ? 11'd0 : x + 1'b1;
        end
    end

    // Stage 2: column shift chain
    reg [7:0] s2_c0, s2_c1, s2_c2;
    reg [7:0] s2_r1c0, s2_r1c1, s2_r1c2;
    reg [7:0] s2_r2c0, s2_r2c1, s2_r2c2;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            {s2_c0,s2_c1,s2_c2} <= 0;
            {s2_r1c0,s2_r1c1,s2_r1c2} <= 0;
            {s2_r2c0,s2_r2c1,s2_r2c2} <= 0;
        end else if (valid_in) begin
            s2_c0 <= s1_curr;      s2_c1 <= s2_c0;      s2_c2 <= s2_c1;
            s2_r1c0 <= s1_row1;    s2_r1c1 <= s2_r1c0;   s2_r1c2 <= s2_r1c1;
            s2_r2c0 <= s1_row2;    s2_r2c1 <= s2_r2c0;   s2_r2c2 <= s2_r2c1;
        end
    end

    // Stage 3: Sobel compute
    // Gx = (s2_c2 + 2*s2_r1c2 + s2_r2c2) - (s2_c0 + 2*s2_r1c0 + s2_r2c0)
    // Gy = (s2_r2c0 + 2*s2_r2c1 + s2_r2c2) - (s2_c0 + 2*s2_c1 + s2_c2)
    wire signed [11:0] gx =
        $signed({1'b0,s2_c2}) + $signed({1'b0,s2_r1c2,1'b0}) + $signed({1'b0,s2_r2c2}) -
        $signed({1'b0,s2_c0}) - $signed({1'b0,s2_r1c0,1'b0}) - $signed({1'b0,s2_r2c0});

    wire signed [11:0] gy =
        $signed({1'b0,s2_r2c0}) + $signed({1'b0,s2_r2c1,1'b0}) + $signed({1'b0,s2_r2c2}) -
        $signed({1'b0,s2_c0}) - $signed({1'b0,s2_c1,1'b0}) - $signed({1'b0,s2_c2});

    wire [11:0] mag = (gx[11] ? -gx : gx) + (gy[11] ? -gy : gy);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            edge_out <= 8'd0;
            valid_out <= 1'b0;
        end else begin
            edge_out <= (mag > 12'd255) ? 8'hFF : mag[7:0];
            valid_out <= valid_in;
        end
    end

endmodule
