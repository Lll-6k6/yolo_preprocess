// tmds_encoder.v -- TMDS 8b/10b encoder (DVI/HDMI compatible)
`timescale 1ns / 1ps

module tmds_encoder (
    input  wire       clk,
    input  wire       rst_n,
    input  wire [7:0] d,
    input  wire       de,
    input  wire [1:0] c,
    output reg  [9:0] q_out
);

    reg [3:0] cnt;
    reg [8:0] q_m;

    wire [3:0] ones = d[0]+d[1]+d[2]+d[3]+d[4]+d[5]+d[6]+d[7];

    always @(*) begin
        if (ones > 4 || (ones == 4 && d[0] == 1'b0)) begin
            // XNOR path
            q_m[0] = d[0];
            q_m[1] = q_m[0] ~^ d[1];
            q_m[2] = q_m[1] ~^ d[2];
            q_m[3] = q_m[2] ~^ d[3];
            q_m[4] = q_m[3] ~^ d[4];
            q_m[5] = q_m[4] ~^ d[5];
            q_m[6] = q_m[5] ~^ d[6];
            q_m[7] = q_m[6] ~^ d[7];
            q_m[8] = 1'b1;
        end else begin
            // XOR path
            q_m[0] = d[0];
            q_m[1] = q_m[0] ^ d[1];
            q_m[2] = q_m[1] ^ d[2];
            q_m[3] = q_m[2] ^ d[3];
            q_m[4] = q_m[3] ^ d[4];
            q_m[5] = q_m[4] ^ d[5];
            q_m[6] = q_m[5] ^ d[6];
            q_m[7] = q_m[6] ^ d[7];
            q_m[8] = 1'b0;
        end
    end

    wire [3:0] ones_m = q_m[0]+q_m[1]+q_m[2]+q_m[3]+q_m[4]+q_m[5]+q_m[6]+q_m[7];

    reg [9:0] q_n;
    reg [3:0] cnt_next;

    always @(*) begin
        if (!de) begin
            case (c)
                2'b00: q_n = 10'b1101010100;
                2'b01: q_n = 10'b0010101011;
                2'b10: q_n = 10'b0101010100;
                2'b11: q_n = 10'b1010101011;
            endcase
            cnt_next = 0;
        end else if (cnt == 0 || ones_m == 4) begin
            q_n[9]   = ~q_m[8];
            q_n[8]   = q_m[8];
            q_n[7:0] = (q_m[8] == 1'b0) ? q_m[7:0] : ~q_m[7:0];
            cnt_next = cnt + ((q_m[8] == 1'b0) ? ones_m - 4'd4 : 4'd4 - ones_m);
        end else begin
            if ((cnt[3] == 1'b0 && ones_m > 4) || (cnt[3] == 1'b1 && ones_m < 4)) begin
                q_n[9]   = 1'b1;
                q_n[8]   = q_m[8];
                q_n[7:0] = ~q_m[7:0];
                cnt_next = cnt - ((q_m[8] == 1'b0) ? ones_m - 4'd4 : 4'd4 - ones_m) + 4'd2;
            end else begin
                q_n[9]   = 1'b0;
                q_n[8]   = q_m[8];
                q_n[7:0] = q_m[7:0];
                cnt_next = cnt + ((q_m[8] == 1'b0) ? ones_m - 4'd4 : 4'd4 - ones_m);
            end
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            q_out <= 0;
            cnt   <= 0;
        end else begin
            q_out <= q_n;
            cnt   <= cnt_next;
        end
    end

endmodule
