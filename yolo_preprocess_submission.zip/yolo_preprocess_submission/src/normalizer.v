// normalizer.v -- pixel normalization for YOLO preprocessing
// Input:  pixel_in [7:0] 0..255 unsigned
// Output: pixel_out [7:0] signed, range about -64..63
// Formula: out = (pixel_in - 128) >> 1
// Pure combinational
`timescale 1ns / 1ps

module normalizer (
    input  wire [7:0] pixel_in,
    output wire [7:0] pixel_out
);

    wire [8:0] signed_p = {1'b0, pixel_in} - 9'sd128;  // -128..127
    assign pixel_out = signed_p[8:1];                  // >> 1, range -64..63

endmodule
