// image_source.v -- test pattern generator (color bars)
// Generates a 64x64 RGB888 image over AXI-Stream
// No camera needed; this is the source of the pipeline
//
// AXI-Stream interface:
//   m_axis_tvalid : out, high when data is valid
//   m_axis_tready : in,  downstream ready
//   m_axis_tdata  : out [23:0], RGB888
//   m_axis_tlast  : out, high on last pixel of a row
//   m_axis_tuser  : out, high on first pixel of the first row (SOF)
`timescale 1ns / 1ps

module image_source #(
    parameter IMG_W = 64,
    parameter IMG_H = 64
)(
    input  wire        clk,
    input  wire        rst_n,
    output reg         m_axis_tvalid,
    input  wire        m_axis_tready,
    output reg  [23:0] m_axis_tdata,
    output reg         m_axis_tlast,
    output reg         m_axis_tuser
);

    localparam COL_W = $clog2(IMG_W);
    localparam ROW_W = $clog2(IMG_H);

    reg [COL_W-1:0] x = 0;
    reg [ROW_W-1:0] y = 0;
    reg             running = 0;   // 0 = idle, 1 = streaming

    wire handshake = m_axis_tvalid & m_axis_tready;

    // 7 color bars: R, G, B, C, M, Y, white
    reg [23:0] bar_colors [0:6];
    initial begin
        bar_colors[0] = 24'hFF0000;
        bar_colors[1] = 24'h00FF00;
        bar_colors[2] = 24'h0000FF;
        bar_colors[3] = 24'h00FFFF;
        bar_colors[4] = 24'hFF00FF;
        bar_colors[5] = 24'hFFFF00;
        bar_colors[6] = 24'hFFFFFF;
    end

    always @(*) begin
        m_axis_tdata  = bar_colors[x[COL_W-1:COL_W-3]];
        m_axis_tlast   = (x == IMG_W-1);
        m_axis_tuser   = (x == 0) && (y == 0);
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            x <= 0; y <= 0;
            m_axis_tvalid <= 0;
            running <= 0;
        end else if (!running) begin
            // start one frame after reset
            running <= 1;
            m_axis_tvalid <= 1;
            x <= 0; y <= 0;
        end else if (handshake) begin
            if (x == IMG_W-1) begin
                x <= 0;
                if (y == IMG_H-1) begin
                    y <= 0;
                    x <= 0;
                    // keep valid high, immediately start next frame
                end else begin
                    y <= y + 1;
                end
            end else begin
                x <= x + 1;
            end
        end
    end

endmodule
