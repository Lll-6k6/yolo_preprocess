// rgb_to_gray.v -- RGB888 to grayscale (BT.601 fixed-point, 8-bit out)
// Y = 0.299*R + 0.587*G + 0.114*B
// Fixed point: Y = (77*R + 150*G + 29*B) >> 8
// Pure combinational, zero cycle delay
`timescale 1ns / 1ps

module rgb_to_gray (
    input  wire [7:0] r,
    input  wire [7:0] g,
    input  wire [7:0] b,
    output wire [7:0] gray
);

    // max: (77+150+29)*255 = 256*255 = 65280 < 65536 = 2^16, use 16 bits
    wire [15:0] y_w = 77*r + 150*g + 29*b;

    // divide by 256
    assign gray = y_w[15:8];

endmodule
