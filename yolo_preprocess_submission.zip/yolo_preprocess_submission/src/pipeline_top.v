// pipeline_top.v -- YOLO preprocessing pipeline top
// image_source -> rgb_to_gray -> avg_filter_3x3 -> normalizer
`timescale 1ns / 1ps

module pipeline_top #(
    parameter IMG_W = 64,
    parameter IMG_H = 64
)(
    input  wire        clk,
    input  wire        rst_n,
    output wire        m_axis_tvalid,
    input  wire        m_axis_tready,
    output wire [7:0]  m_axis_tdata,
    output wire        m_axis_tlast,
    output wire        m_axis_tuser
);

    wire        src_valid;
    wire        src_ready;
    wire [23:0] src_data;
    wire        src_last;
    wire        src_user;

    wire [7:0] gray;
    wire        gray_valid;

    wire [7:0] filtered;
    wire        filtered_valid;

    wire [7:0] normalized;

    // tlast/tuser delayed 3 cycles to align with filter pipeline
    reg [2:0] last_dly = 0;
    reg [2:0] user_dly  = 0;

    image_source #(.IMG_W(IMG_W), .IMG_H(IMG_H)) u_src (
        .clk(clk), .rst_n(rst_n),
        .m_axis_tvalid(src_valid),
        .m_axis_tready(src_ready),
        .m_axis_tdata(src_data),
        .m_axis_tlast(src_last),
        .m_axis_tuser(src_user)
    );

    rgb_to_gray u_gray (
        .r(src_data[23:16]), .g(src_data[15:8]), .b(src_data[7:0]),
        .gray(gray)
    );

    assign gray_valid = src_valid & src_ready;

    avg_filter_3x3 #(.IMG_W(IMG_W)) u_filter (
        .clk(clk), .rst_n(rst_n),
        .pixel_in(gray),
        .valid_in(gray_valid),
        .pixel_out(filtered),
        .valid_out(filtered_valid)
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            last_dly <= 0;
            user_dly <= 0;
        end else begin
            last_dly <= {last_dly[1:0], src_last};
            user_dly <= {user_dly[1:0], src_user};
        end
    end

    normalizer u_norm (
        .pixel_in(filtered),
        .pixel_out(normalized)
    );

    assign src_ready = m_axis_tready;
    assign m_axis_tvalid = filtered_valid;
    assign m_axis_tdata  = normalized;
    assign m_axis_tlast  = last_dly[2];
    assign m_axis_tuser  = user_dly[2];

endmodule
