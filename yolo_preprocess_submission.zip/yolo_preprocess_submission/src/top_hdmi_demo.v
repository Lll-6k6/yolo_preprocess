// top_hdmi_demo.v -- Auto-cycling demo with rich test patterns
// 7 modes auto-cycle every 2 seconds, K1 for manual
// Modes: color, gray, blur, sobel, quad, gamma, letterbox
`timescale 1ns / 1ps

module top_hdmi_demo (
    input  wire       clk_50m,
    output wire       hdmi_clk_p,
    output wire       hdmi_clk_n,
    output wire       hdmi_d0_p,
    output wire       hdmi_d0_n,
    output wire       hdmi_d1_p,
    output wire       hdmi_d1_n,
    output wire       hdmi_d2_p,
    output wire       hdmi_d2_n,
    input  wire       key1,
    output wire       led1,
    output wire       led2
);

    wire pixel_clk;
    wire serial_clk;
    wire locked;
    wire rst_n = locked;

    clk_wiz_0 u_clk (
        .clk_in1(clk_50m),
        .pixel_clk(pixel_clk),
        .serial_clk(serial_clk),
        .reset(1'b0),
        .locked(locked)
    );

    wire [10:0] hcnt, vcnt;
    wire hs, vs, de, active;

    video_timing u_vt (
        .pixel_clk(pixel_clk), .rst_n(rst_n),
        .hcnt(hcnt), .vcnt(vcnt),
        .hs(hs), .vs(vs), .de(de), .active(active)
    );

    // frame counter
    reg vs_d;
    reg [15:0] frame_cnt;
    always @(posedge pixel_clk or negedge rst_n) begin
        if (!rst_n) begin
            vs_d <= 0; frame_cnt <= 0;
        end else begin
            vs_d <= vs;
            if (vs & ~vs_d) frame_cnt <= frame_cnt + 1'b1;
        end
    end

    // auto mode switch: every 120 frames (~2 sec)
    reg [2:0] auto_mode;
    always @(posedge pixel_clk or negedge rst_n) begin
        if (!rst_n) auto_mode <= 0;
        else if (vs & ~vs_d && frame_cnt[6:0] == 7'd119)
            auto_mode <= (auto_mode == 3'd6) ? 3'd0 : auto_mode + 1'b1;
    end

    // manual key override
    reg key_d1, key_d2;
    reg [2:0] manual_mode;
    reg manual_en;
    always @(posedge pixel_clk or negedge rst_n) begin
        if (!rst_n) begin
            key_d1 <= 1; key_d2 <= 1; manual_mode <= 0; manual_en <= 0;
        end else begin
            key_d1 <= key1;
            key_d2 <= key_d1;
            if (key_d2 && !key_d1) begin
                manual_mode <= (manual_mode == 3'd6) ? 3'd0 : manual_mode + 1'b1;
                manual_en <= 1;
            end
        end
    end

    wire [2:0] cur_mode = manual_en ? manual_mode : auto_mode;

    // independent moving square position (continuous across mode switches)
    // moves within letterbox region x=256..768 (square 80 wide, so 256..688)
    reg [10:0] sq_pos;
    always @(posedge pixel_clk or negedge rst_n) begin
        if (!rst_n)
            sq_pos <= 11'd256;
        else if (vs & ~vs_d) begin
            if (sq_pos >= 11'd688)
                sq_pos <= 11'd256;
            else
                sq_pos <= sq_pos + 11'd2;  // 2 pixels per frame
        end
    end

    wire [10:0] sq_x = sq_pos;
    wire [10:0] sq_y = 11'd200;
    wire in_square = (hcnt >= sq_x && hcnt < sq_x + 80 &&
                      vcnt >= sq_y && vcnt < sq_y + 80);
    wire in_ground = (vcnt >= 450);

    reg [7:0] src_r, src_g, src_b;
    always @(*) begin
        if (active) begin
            if (in_square) begin
                // red moving square (R/B swapped: output B to get red on screen)
                src_r = 8'h40; src_g = 8'h40; src_b = 8'hFF;
            end else if (in_ground) begin
                // green ground
                src_r = 8'h40; src_g = 8'hA0; src_b = 8'h40;
            end else begin
                // sky gradient: light blue at top, darker at horizon
                // (R/B swapped: output R to get blue on screen)
                src_r = 8'hFF;
                src_g = 8'hA0 + vcnt[6:0];
                src_b = 8'h80 + vcnt[6:0];
            end
        end else begin
            src_r = 8'd0; src_g = 8'd0; src_b = 8'd0;
        end
    end

    // RGB to gray
    wire [7:0] gray;
    rgb_to_gray u_r2g (.r(src_r), .g(src_g), .b(src_b), .gray(gray));

    // blur
    wire [7:0] gray_blur;
    wire blur_valid;
    avg_filter_3x3 #(.IMG_W(1024)) u_blur (
        .clk(pixel_clk), .rst_n(rst_n),
        .pixel_in(gray), .valid_in(de),
        .pixel_out(gray_blur), .valid_out(blur_valid)
    );

    // sobel
    wire [7:0] edge_pix;
    wire edge_valid;
    sobel_edge #(.IMG_W(1024)) u_sobel (
        .clk(pixel_clk), .rst_n(rst_n),
        .pixel_in(gray), .valid_in(de),
        .edge_out(edge_pix), .valid_out(edge_valid)
    );

    // gamma
    wire [15:0] gamma_raw = gray * gray;
    wire [7:0] gamma_pix = gamma_raw[15:8];

    // de/hs/vs delay
    reg de_d1, de_d2, de_d3;
    reg hs_d1, hs_d2, hs_d3;
    reg vs_d1, vs_d2, vs_d3;
    always @(posedge pixel_clk or negedge rst_n) begin
        if (!rst_n) begin
            {de_d1,de_d2,de_d3} <= 0;
            {hs_d1,hs_d2,hs_d3} <= 0;
            {vs_d1,vs_d2,vs_d3} <= 0;
        end else begin
            de_d1 <= de;    de_d2 <= de_d1;  de_d3 <= de_d2;
            hs_d1 <= hs;    hs_d2 <= hs_d1;  hs_d3 <= hs_d2;
            vs_d1 <= vs;    vs_d2 <= vs_d1;  vs_d3 <= vs_d2;
        end
    end

    // output
    reg [7:0] out_r, out_g, out_b;
    always @(*) begin
        if (!de_d3) begin
            out_r = 8'd0; out_g = 8'd0; out_b = 8'd0;
        end else begin
        case (cur_mode)
            3'd0: begin  // color gradient + circle
                out_r = src_r; out_g = src_g; out_b = src_b;
            end
            3'd1: begin  // grayscale
                out_r = gray; out_g = gray; out_b = gray;
            end
            3'd2: begin  // blur
                out_r = gray_blur; out_g = gray_blur; out_b = gray_blur;
            end
            3'd3: begin  // sobel
                out_r = edge_pix; out_g = edge_pix; out_b = edge_pix;
            end
            3'd4: begin  // quad split
                if (hcnt < 512 && vcnt < 300) begin
                    out_r = src_r; out_g = src_g; out_b = src_b;
                end else if (hcnt >= 512 && vcnt < 300) begin
                    out_r = gray; out_g = gray; out_b = gray;
                end else if (hcnt < 512 && vcnt >= 300) begin
                    out_r = gray_blur; out_g = gray_blur; out_b = gray_blur;
                end else begin
                    out_r = edge_pix; out_g = edge_pix; out_b = edge_pix;
                end
            end
            3'd5: begin  // gamma
                out_r = gamma_pix; out_g = gamma_pix; out_b = gamma_pix;
            end
            3'd6: begin  // letterbox: center 512x300 region, black bars
                if (hcnt >= 256 && hcnt < 768 && vcnt >= 150 && vcnt < 450) begin
                    // show original image inside centered region
                    out_r = src_r;
                    out_g = src_g;
                    out_b = src_b;
                end else begin
                    out_r = 8'd0; out_g = 8'd0; out_b = 8'd0;
                end
            end
            default: begin
                out_r = src_r; out_g = src_g; out_b = src_b;
            end
        endcase
        end
    end

    // TMDS
    wire [9:0] tmds_r, tmds_g, tmds_b;
    tmds_encoder u_enc_r (.clk(pixel_clk), .rst_n(rst_n), .d(out_r), .de(de_d3), .c(2'b00), .q_out(tmds_r));
    tmds_encoder u_enc_g (.clk(pixel_clk), .rst_n(rst_n), .d(out_g), .de(de_d3), .c(2'b00), .q_out(tmds_g));
    tmds_encoder u_enc_b (.clk(pixel_clk), .rst_n(rst_n), .d(out_b), .de(de_d3), .c({vs_d3,hs_d3}), .q_out(tmds_b));

    wire ser_r, ser_g, ser_b, ser_clk;
    serializer u_ser_r (.pixel_clk(pixel_clk), .serial_clk(serial_clk), .rst_n(rst_n), .data_in(tmds_r), .ser_out(ser_r));
    serializer u_ser_g (.pixel_clk(pixel_clk), .serial_clk(serial_clk), .rst_n(rst_n), .data_in(tmds_g), .ser_out(ser_g));
    serializer u_ser_b (.pixel_clk(pixel_clk), .serial_clk(serial_clk), .rst_n(rst_n), .data_in(tmds_b), .ser_out(ser_b));
    serializer u_ser_clk (.pixel_clk(pixel_clk), .serial_clk(serial_clk), .rst_n(rst_n), .data_in(10'h3E0), .ser_out(ser_clk));

    OBUFDS #(.IOSTANDARD("TMDS_33")) obuf_r (.I(ser_r), .O(hdmi_d2_p), .OB(hdmi_d2_n));
    OBUFDS #(.IOSTANDARD("TMDS_33")) obuf_g (.I(ser_g), .O(hdmi_d1_p), .OB(hdmi_d1_n));
    OBUFDS #(.IOSTANDARD("TMDS_33")) obuf_b (.I(ser_b), .O(hdmi_d0_p), .OB(hdmi_d0_n));
    OBUFDS #(.IOSTANDARD("TMDS_33")) obuf_clk (.I(ser_clk), .O(hdmi_clk_p), .OB(hdmi_clk_n));

    assign led1 = ~locked;
    assign led2 = ~frame_cnt[5];

endmodule
